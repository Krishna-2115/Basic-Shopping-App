import React from 'react';
import { useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { FiHeart } from 'react-icons/fi';
import { AiOutlineShoppingCart, AiOutlineSearch } from 'react-icons/ai';
import './Nav.css';

const Nav = ({ handleInputChange, query }) => {
  const navigate = useNavigate();
  const cartItems = useSelector((state) => state.cart.items);  // Accessing cart items from Redux state
  const cartItemCount = cartItems.reduce((total, item) => total + item.quantity, 0);  // Calculating total items in the cart

  const handleCartClick = () => {
    navigate('/cart');  // Navigate to cart page
  };

  return (
    <nav>
      <div className="nav-container">
        <div className="search-wrapper">
          <AiOutlineSearch className="search-icon" />
          <input
            className="search-input"
            type="text"
            onChange={handleInputChange}
            value={query}
            placeholder="Enter your search shoes."
          />
        </div>
      </div>
      <div className="profile-container">
        <a href="#a">
          <FiHeart className="nav-icons" />
        </a>
        <a href="#a">
          <AiOutlineShoppingCart
            className="nav-icons"
            onClick={handleCartClick}  // Handle click to navigate to cart
          />
          {cartItemCount > 0 && (
            <div className="cart-item-count">{cartItemCount}</div>  // Show item count if more than 0
          )}
        </a>
      </div>
    </nav>
  );
};

export default Nav;
