import React, { useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { resetCart } from '../store/cartSlice'; // Import resetCart action
import './Checkout.css';

const Checkout = () => {
    const cartItems = useSelector((state) => state.cart.items);
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        address: '',
        paymentMethod: 'creditCard',
    });
    const [isModalOpen, setIsModalOpen] = useState(false);

    const calculateTotal = () => {
        return cartItems.reduce((total, item) => total + item.price * item.quantity, 0).toFixed(2);
    };

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
    };

    const handlePlaceOrder = () => {
        // Validate form fields
        if (!formData.name || !formData.email || !formData.address) {
            alert('Please fill in all required fields.');
            return;
        }

        setIsModalOpen(true); // Open modal if validation passes
    };

    const handleModalClose = () => {
        setIsModalOpen(false);
        dispatch(resetCart()); // Clear the cart
        navigate('/'); // Navigate to the home page
    };

    return (
        <div className="checkout-container">
            <h2 className="checkout-title">Checkout</h2>
            <div className="checkout-content">
                <div className="order-summary">
                    <h3>Order Summary</h3>
                    <ul className="order-items">
                        {cartItems.map((item) => (
                            <li key={item.id} className="order-item">
                                <span>{item.title} (x{item.quantity})</span>
                                <span>${(item.price * item.quantity).toFixed(2)}</span>
                            </li>
                        ))}
                    </ul>
                    <div className="order-total">
                        <strong>Total:</strong> <span>${calculateTotal()}</span>
                    </div>
                </div>

                <div className="checkout-form">
                    <h3>Billing & Shipping Information</h3>
                    <form>
                        <div className="form-group">
                            <label htmlFor="name">Full Name</label>
                            <input
                                type="text"
                                id="name"
                                name="name"
                                value={formData.name}
                                onChange={handleInputChange}
                                required
                            />
                        </div>
                        <div className="form-group">
                            <label htmlFor="email">Email Address</label>
                            <input
                                type="email"
                                id="email"
                                name="email"
                                value={formData.email}
                                onChange={handleInputChange}
                                required
                            />
                        </div>
                        <div className="form-group">
                            <label htmlFor="address">Shipping Address</label>
                            <input
                                type="text"
                                id="address"
                                name="address"
                                value={formData.address}
                                onChange={handleInputChange}
                                required
                            />
                        </div>
                        <div className="form-group">
                            <label htmlFor="paymentMethod">Payment Method</label>
                            <select
                                id="paymentMethod"
                                name="paymentMethod"
                                value={formData.paymentMethod}
                                onChange={handleInputChange}
                            >
                                <option value="creditCard">Credit Card</option>
                                <option value="paypal">PayPal</option>
                                <option value="cashOnDelivery">Cash on Delivery</option>
                            </select>
                        </div>
                    </form>
                </div>
            </div>

            <div className="checkout-actions">
                <button className="place-order-btn" onClick={handlePlaceOrder}>
                    Place Order
                </button>
                <button className="back-to-cart-btn" onClick={() => navigate('/cart')}>
                    Back to Cart
                </button>
            </div>

            {isModalOpen && (
                <div className="modal-overlay">
                    <div className="modal-content">
                        <h2>Thank You!</h2>
                        <p>Your order has been placed successfully.</p>
                        <p>We appreciate your business!</p>
                        <button className="close-modal-btn" onClick={handleModalClose}>
                            Back to Home
                        </button>
                    </div>
                </div>
            )}
        </div>
    );
};

export default Checkout;
